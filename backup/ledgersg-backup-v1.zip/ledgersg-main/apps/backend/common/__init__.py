"""Common module for LedgerSG."""

default_app_config = 'common.apps.CommonConfig'
